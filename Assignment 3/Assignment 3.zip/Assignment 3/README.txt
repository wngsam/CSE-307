############################
#CSE 307-01 ASSIGNMENT 3   #
#  Prof. Annie Liu         #
#By Sam Wang, ID: 108107971#
############################
# Mar. 28, 2014 #
#################

Included Files:
-a3main.py
-tpg.py
-a3input1.txt
-a3output1.txt
-a3input4.txt
-a3output4.txt
-README.txt

How to Run:
- Extract files.
- Launch a3main.py via command line .
- Be sure to include your input filename as the argument.
(You can use the included 'a3input1.txt'.)
- An output should be printed on console.
(If you used the included txt file, the results should match the data in 'a3output1.txt'.

What I did/Explanations:
Implemented evaluation and initialization methods for all node classes to be recursively called and analyzed.

Results:
The program have been tested with all the example inputs provided by the handout and return some desired results and
missing others. Variable scopes were not implemented.

Credits:
Code by Professor Liu

All information were learned from reading:
Class lectures
Google Q/A forum