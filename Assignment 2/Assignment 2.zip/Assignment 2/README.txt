############################
#CSE 307-01 ASSIGNMENT 2   #
#  Prof. Annie Liu         #
#By Sam Wang, ID: 108107971#
############################
# Feb. 27, 2014 #
#################

Included Files:
-a2main.py
-tpg.py
-a2input0.txt
-a2output0.txt
-README.txt

How to Run:
- Extract files.
- Launch a2main.py via command line .
- Be sure to include your input filename as the argument.
(You can use the included 'a2input0.txt'.)
- An output should be printed on console.
(If you used the included txt file, the results should match the data in '12output0.txt'.

What I did/Explanations:
Various classes for different operations were made by adapting from the existing classes.
The rules for the parser was extended by analyzing the existing grammar (for division and multiplication)

Results:
The program have been tested with all the example inputs provided by the handout and returns desired results.

Credits:
Code by Professor Liu

All information were learned from reading:
Class lectures
Google Q/A forum
TPG Document